public class Zmienne {
    public static void main(String[] args) {

        //Typ             nazwa                wartość
          int    nazwaZmiennejJestDowolna  =     15;

        //Deklaracja
        int x;

        //Inicjalizacja
        x = 10;

        //Deklaracja i inicjalizacja w jednej linii
        int y = 7;

        System.out.println("Zmienna nazwaZmiennejJestDowolna: " + nazwaZmiennejJestDowolna);
        System.out.println("Zmienna x: " + x);
        System.out.println("Zmienna y: " + y);
    }
}
